## Ansible Deployment Package Structure

Place the following files in this directory before running the playbook:

```
ansible/
├── wazuh-agent-deploy.yml          # Main playbook
├── inventory/
│   └── hosts.ini                   # Edit with your hosts
├── group_vars/
│   └── all.yml                     # Default variables
└── packages/
    └── linux/
        ├── wazuh-agent-4.9.2-1.x86_64.rpm      # Copy from /opt/wazuh-offline/agents/linux/
        └── wazuh-agent_4.9.2-1_amd64.deb        # Copy from /opt/wazuh-offline/agents/linux/
```

## Running the Playbook

```bash
# Basic run (prompts for sudo password)
ansible-playbook wazuh-agent-deploy.yml \
  -i inventory/hosts.ini \
  --become -K

# Override manager IP and group
ansible-playbook wazuh-agent-deploy.yml \
  -i inventory/hosts.ini \
  -e "wazuh_manager_ip=192.168.1.10" \
  -e "wazuh_agent_group=servers" \
  --become -K

# Target a single host
ansible-playbook wazuh-agent-deploy.yml \
  -i inventory/hosts.ini \
  --limit rocky-ws-01 \
  --become -K

# Dry run (check mode)
ansible-playbook wazuh-agent-deploy.yml \
  -i inventory/hosts.ini \
  --check --diff \
  --become -K
```

## Encrypting the Registration Password with Ansible Vault

```bash
ansible-vault encrypt_string 'AgentReg@2024!' --name 'wazuh_reg_pass'
```

Paste the output into group_vars/all.yml, replacing the plaintext password.
Then run the playbook with --ask-vault-pass or --vault-password-file.
