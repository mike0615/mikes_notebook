#!/bin/bash
# ==============================================================================
# Wazuh Community Edition - Air-Gapped Installer
# Version: 1.0
# Target: Rocky Linux 9.7 Minimal (Air-Gapped)
# Author: Anderson Computer Consulting
# Description:
#   Run this script on your air-gapped Rocky Linux 9.7 minimal VM AFTER
#   copying the /opt/wazuh-offline directory from the collector machine.
#   Installs Wazuh Manager, Indexer, and Dashboard as a single-node stack.
# ==============================================================================

set -euo pipefail

# ---- Source Configuration ----
OFFLINE_DIR="/opt/wazuh-offline"
CONFIG_FILE="${OFFLINE_DIR}/configs/config.ini"

[[ ! -f "$CONFIG_FILE" ]] && {
    echo "[ERROR] Config file not found: $CONFIG_FILE"
    echo "        Ensure /opt/wazuh-offline was copied from the collector machine."
    exit 1
}

# Parse config.ini
parse_ini() {
    local section="$1" key="$2"
    awk -F= "/^\[${section}\]/{found=1; next} /^\[/{found=0} found && /^${key}[[:space:]]*=/{print \$2; exit}" \
        "$CONFIG_FILE" | tr -d ' '
}

WAZUH_MANAGER_IP=$(parse_ini server WAZUH_MANAGER_IP)
HOSTNAME_VAL=$(parse_ini server HOSTNAME)
INDEXER_NODE=$(parse_ini indexer INDEXER_NODE_NAME)
INDEXER_ADMIN_PASS=$(parse_ini credentials INDEXER_ADMIN_PASS)
API_USER=$(parse_ini credentials API_USER)
API_PASS=$(parse_ini credentials API_PASS)
AGENT_REG_PASS=$(parse_ini credentials AGENT_REG_PASS)
BIND_IF=$(parse_ini network BIND_INTERFACE)

WAZUH_VERSION="4.9.2"
LOG_FILE="/var/log/wazuh-install.log"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

log()   { echo -e "${GREEN}[$(date '+%H:%M:%S')] $*${NC}" | tee -a "$LOG_FILE"; }
warn()  { echo -e "${YELLOW}[WARN] $*${NC}" | tee -a "$LOG_FILE"; }
error() { echo -e "${RED}[ERROR] $*${NC}" | tee -a "$LOG_FILE"; exit 1; }
info()  { echo -e "${CYAN}[INFO] $*${NC}" | tee -a "$LOG_FILE"; }
step()  { echo -e "\n${CYAN}━━━ $* ━━━${NC}\n" | tee -a "$LOG_FILE"; }

# ==============================================================================
# PRE-FLIGHT CHECKS
# ==============================================================================
preflight() {
    step "Pre-Flight Checks"
    [[ $EUID -ne 0 ]] && error "Must be run as root."

    # Verify offline package directory
    for dir in rpms/wazuh rpms/deps agents; do
        [[ -d "${OFFLINE_DIR}/${dir}" ]] || error "Missing directory: ${OFFLINE_DIR}/${dir}"
    done

    # Verify no internet is needed (we should NOT have internet)
    MEM_TOTAL_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    MEM_TOTAL_GB=$(( MEM_TOTAL_KB / 1024 / 1024 ))
    [[ $MEM_TOTAL_GB -lt 8 ]] && warn "System has ${MEM_TOTAL_GB}GB RAM. Recommend 16GB minimum for production."

    CPU_COUNT=$(nproc)
    [[ $CPU_COUNT -lt 4 ]] && warn "Only ${CPU_COUNT} vCPU(s) detected. Recommend 8+ for production."

    DISK_FREE=$(df -BG / | awk 'NR==2 {print $4}' | tr -d 'G')
    [[ $DISK_FREE -lt 50 ]] && warn "Only ${DISK_FREE}GB free. Recommend 200GB+ for log retention."

    log "Pre-flight checks complete. RAM: ${MEM_TOTAL_GB}GB, CPU: ${CPU_COUNT} cores, Disk free: ${DISK_FREE}GB"
}

# ==============================================================================
# SYSTEM PREPARATION
# ==============================================================================
prepare_system() {
    step "Preparing System"

    # Set hostname
    hostnamectl set-hostname "${HOSTNAME_VAL}" 2>&1 | tee -a "$LOG_FILE"

    # Disable existing external repos to enforce air-gapped operation
    find /etc/yum.repos.d/ -name "*.repo" ! -name "wazuh-local.repo" ! -name "deps-local.repo" \
        -exec rename .repo .repo.disabled {} \; 2>/dev/null || true

    # Install local repo files
    cp "${OFFLINE_DIR}/configs/wazuh-local.repo" /etc/yum.repos.d/
    cp "${OFFLINE_DIR}/configs/deps-local.repo"  /etc/yum.repos.d/

    # Update the baseurl to match actual offline dir path
    sed -i "s|/opt/wazuh-offline|${OFFLINE_DIR}|g" /etc/yum.repos.d/wazuh-local.repo
    sed -i "s|/opt/wazuh-offline|${OFFLINE_DIR}|g" /etc/yum.repos.d/deps-local.repo

    log "Local repos configured."

    # Install base dependencies from local repo
    dnf install -y --disablerepo='*' --enablerepo='wazuh-local,deps-local' \
        curl wget tar openssl ca-certificates \
        java-11-openjdk-headless \
        policycoreutils-python-utils \
        audit 2>&1 | tee -a "$LOG_FILE" || warn "Some base deps may already be installed."

    # Configure audit
    systemctl enable --now auditd 2>&1 | tee -a "$LOG_FILE" || true

    # Disable swap (recommended for Wazuh Indexer / OpenSearch)
    swapoff -a || true
    sed -i '/swap/d' /etc/fstab

    # Set kernel parameters for OpenSearch
    cat >> /etc/sysctl.d/99-wazuh.conf <<EOF
vm.max_map_count = 262144
net.core.somaxconn = 65535
EOF
    sysctl --system 2>&1 | tee -a "$LOG_FILE" | tail -5

    # Increase file descriptors
    cat >> /etc/security/limits.conf <<EOF
wazuh soft nofile 65536
wazuh hard nofile 65536
EOF

    # Firewall rules
    if systemctl is-active --quiet firewalld; then
        log "Configuring firewalld rules..."
        firewall-cmd --permanent --add-port=1514/tcp   # Agent communication
        firewall-cmd --permanent --add-port=1515/tcp   # Agent registration
        firewall-cmd --permanent --add-port=514/udp    # Syslog
        firewall-cmd --permanent --add-port=9200/tcp   # Indexer REST API
        firewall-cmd --permanent --add-port=9300/tcp   # Indexer cluster
        firewall-cmd --permanent --add-port=443/tcp    # Dashboard HTTPS
        firewall-cmd --permanent --add-port=55000/tcp  # Manager API
        firewall-cmd --reload
    else
        warn "firewalld not active. Ensure necessary ports are opened manually."
    fi

    # SELinux permissive (Wazuh recommends this for initial setup; harden after)
    setenforce 0 || true
    sed -i 's/^SELINUX=enforcing/SELINUX=permissive/' /etc/selinux/config

    log "System preparation complete."
}

# ==============================================================================
# GENERATE CERTIFICATES
# ==============================================================================
generate_certificates() {
    step "Generating TLS Certificates"

    CERT_SCRIPT="${OFFLINE_DIR}/scripts/wazuh-certs-tool.sh"
    [[ ! -f "$CERT_SCRIPT" ]] && error "Certificate tool not found: $CERT_SCRIPT"

    cat > /tmp/config.yml <<EOF
nodes:
  indexer:
    - name: ${INDEXER_NODE}
      ip: "${WAZUH_MANAGER_IP}"

  server:
    - name: wazuh-1
      ip: "${WAZUH_MANAGER_IP}"

  dashboard:
    - name: dashboard
      ip: "${WAZUH_MANAGER_IP}"
EOF

    bash "${CERT_SCRIPT}" -A -ca /tmp/config.yml 2>&1 | tee -a "$LOG_FILE"

    mkdir -p /etc/wazuh-install-files/certs
    tar -xzf wazuh-certificates.tar.gz -C /etc/wazuh-install-files/certs/ 2>&1 | tee -a "$LOG_FILE"

    cp -r /etc/wazuh-install-files/certs "${OFFLINE_DIR}/certs/"

    log "Certificates generated and stored."
}

# ==============================================================================
# INSTALL WAZUH INDEXER
# ==============================================================================
install_indexer() {
    step "Installing Wazuh Indexer"

    dnf install -y --disablerepo='*' --enablerepo='wazuh-local' \
        wazuh-indexer 2>&1 | tee -a "$LOG_FILE"

    # Deploy certificates
    CERTS_DIR="/etc/wazuh-install-files/certs"
    INDEXER_CERT_DIR="/etc/wazuh-indexer/certs"
    mkdir -p "$INDEXER_CERT_DIR"

    cp "${CERTS_DIR}/${INDEXER_NODE}.pem"     "${INDEXER_CERT_DIR}/indexer.pem"
    cp "${CERTS_DIR}/${INDEXER_NODE}-key.pem" "${INDEXER_CERT_DIR}/indexer-key.pem"
    cp "${CERTS_DIR}/admin.pem"               "${INDEXER_CERT_DIR}/admin.pem"
    cp "${CERTS_DIR}/admin-key.pem"           "${INDEXER_CERT_DIR}/admin-key.pem"
    cp "${CERTS_DIR}/root-ca.pem"             "${INDEXER_CERT_DIR}/root-ca.pem"

    chown -R wazuh-indexer:wazuh-indexer "${INDEXER_CERT_DIR}"
    chmod 500 "${INDEXER_CERT_DIR}"
    chmod 400 "${INDEXER_CERT_DIR}"/*.pem

    # Configure indexer
    cat > /etc/wazuh-indexer/opensearch.yml <<EOF
network.host: "${WAZUH_MANAGER_IP}"
node.name: "${INDEXER_NODE}"
cluster.initial_master_nodes:
- "${INDEXER_NODE}"

plugins.security.ssl.http.pemcert_filepath: ${INDEXER_CERT_DIR}/indexer.pem
plugins.security.ssl.http.pemkey_filepath: ${INDEXER_CERT_DIR}/indexer-key.pem
plugins.security.ssl.http.pemtrustedcas_filepath: ${INDEXER_CERT_DIR}/root-ca.pem
plugins.security.ssl.transport.pemcert_filepath: ${INDEXER_CERT_DIR}/indexer.pem
plugins.security.ssl.transport.pemkey_filepath: ${INDEXER_CERT_DIR}/indexer-key.pem
plugins.security.ssl.transport.pemtrustedcas_filepath: ${INDEXER_CERT_DIR}/root-ca.pem
plugins.security.ssl.http.enabled: true
plugins.security.ssl.transport.enforce_hostname_verification: false
plugins.security.ssl.transport.resolve_hostname: false
plugins.security.authcz.admin_dn:
- "CN=admin,OU=Wazuh,O=Wazuh,L=California,C=US"
plugins.security.check_snapshot_restore_write_privileges: true
plugins.security.enable_snapshot_restore_privilege: true
plugins.security.nodes_dn:
- "CN=${INDEXER_NODE},OU=Wazuh,O=Wazuh,L=California,C=US"
plugins.security.restapi.roles_enabled:
- "all_access"
- "security_rest_api_access"
plugins.security.system_indices.enabled: true
plugins.security.system_indices.indices: [".plugins-ml-model", ".plugins-ml-task", ".opendistro-alerting-config", ".opendistro-alerting-alert*", ".opendistro-anomaly-results*", ".opendistro-anomaly-detector*", ".opendistro-anomaly-checkpoints", ".opendistro-anomaly-detection-state", ".opendistro-reports-*", ".opensearch-notifications-*", ".opensearch-notebooks", ".opensearch-observability", ".opendistro-asynchronous-search-response*", ".replication-metadata-store"]
path.data: /var/lib/wazuh-indexer
path.logs: /var/log/wazuh-indexer
EOF

    systemctl daemon-reload
    systemctl enable wazuh-indexer
    systemctl start wazuh-indexer
    sleep 30

    # Initialize security configuration
    log "Initializing Indexer security plugin..."
    JAVA_HOME=/usr/share/wazuh-indexer/jdk \
        bash /usr/share/wazuh-indexer/plugins/opensearch-security/tools/securityadmin.sh \
        -cd /etc/wazuh-indexer/opensearch-security/ \
        -nhnv \
        -cacert "${INDEXER_CERT_DIR}/root-ca.pem" \
        -cert "${INDEXER_CERT_DIR}/admin.pem" \
        -key "${INDEXER_CERT_DIR}/admin-key.pem" \
        -p 9200 \
        -icl 2>&1 | tee -a "$LOG_FILE"

    log "Wazuh Indexer installed and running."
}

# ==============================================================================
# INSTALL WAZUH MANAGER
# ==============================================================================
install_manager() {
    step "Installing Wazuh Manager"

    dnf install -y --disablerepo='*' --enablerepo='wazuh-local' \
        wazuh-manager 2>&1 | tee -a "$LOG_FILE"

    # Deploy configuration
    cp "${OFFLINE_DIR}/configs/wazuh_template.conf" /var/ossec/etc/ossec.conf

    # Set agent registration password
    cat > /var/ossec/etc/authd.pass <<EOF
${AGENT_REG_PASS}
EOF
    chmod 640 /var/ossec/etc/authd.pass
    chown root:wazuh /var/ossec/etc/authd.pass

    systemctl daemon-reload
    systemctl enable wazuh-manager
    systemctl start wazuh-manager
    sleep 15

    # Verify manager is running
    systemctl is-active wazuh-manager || error "Wazuh Manager failed to start. Check logs."

    # Configure Wazuh Manager API
    cat > /var/ossec/api/configuration/api.yaml <<EOF
host: "0.0.0.0"
port: 55000
drop_privileges: true
experimental_features: false

https:
  enabled: true
  key: "server.key"
  cert: "server.crt"
  use_ca: false
  ca: "ca.crt"
  ssl_protocol: "auto"
  ssl_ciphers: ""

logging:
  level: "info"
  format: "plain"

cors:
  enabled: false
  source_route: "*"
  expose_headers: "*"
  allow_headers: "*"
  allow_credentials: false

access:
  max_login_attempts: 50
  block_time: 300
  max_request_per_minute: 300
EOF

    # Create API user
    cd /var/ossec/api/configuration/security/
    python3 /var/ossec/framework/python/bin/python3 \
        /var/ossec/api/scripts/wazuh-apid.py --create-user "${API_USER}" "${API_PASS}" \
        2>&1 | tee -a "$LOG_FILE" || warn "API user may already exist."

    systemctl restart wazuh-manager
    log "Wazuh Manager installed and configured."
}

# ==============================================================================
# INSTALL WAZUH DASHBOARD
# ==============================================================================
install_dashboard() {
    step "Installing Wazuh Dashboard"

    dnf install -y --disablerepo='*' --enablerepo='wazuh-local' \
        wazuh-dashboard 2>&1 | tee -a "$LOG_FILE"

    DASH_CERT_DIR="/etc/wazuh-dashboard/certs"
    CERTS_DIR="/etc/wazuh-install-files/certs"
    mkdir -p "$DASH_CERT_DIR"

    cp "${CERTS_DIR}/dashboard.pem"     "${DASH_CERT_DIR}/dashboard.pem"
    cp "${CERTS_DIR}/dashboard-key.pem" "${DASH_CERT_DIR}/dashboard-key.pem"
    cp "${CERTS_DIR}/root-ca.pem"       "${DASH_CERT_DIR}/root-ca.pem"

    chown -R wazuh-dashboard:wazuh-dashboard "${DASH_CERT_DIR}"
    chmod 500 "${DASH_CERT_DIR}"
    chmod 400 "${DASH_CERT_DIR}"/*.pem

    cat > /etc/wazuh-dashboard/opensearch_dashboards.yml <<EOF
server.host: "0.0.0.0"
server.port: 443
opensearch.hosts: https://${WAZUH_MANAGER_IP}:9200
opensearch.ssl.verificationMode: certificate
opensearch.requestHeadersWhitelist: ["securitytenant","Authorization"]
opensearch_security.multitenancy.enabled: false
opensearch_security.readonly_mode.roles: ["kibana_read_only"]
server.ssl.enabled: true
server.ssl.key: "${DASH_CERT_DIR}/dashboard-key.pem"
server.ssl.certificate: "${DASH_CERT_DIR}/dashboard.pem"
opensearch.ssl.certificateAuthorities: ["${DASH_CERT_DIR}/root-ca.pem"]
uiSettings.overrides.defaultRoute: /app/wazuh
EOF

    systemctl daemon-reload
    systemctl enable wazuh-dashboard
    systemctl start wazuh-dashboard
    sleep 20

    # Connect Dashboard to Manager API
    curl -s -k -X POST \
        "https://${WAZUH_MANAGER_IP}:443/elastic/default/wazuh-check-setup" \
        -H "Content-Type: application/json" \
        -u admin:"${INDEXER_ADMIN_PASS}" \
        -d "{\"ip\": \"${WAZUH_MANAGER_IP}\", \"port\": 55000, \"username\": \"${API_USER}\", \"password\": \"${API_PASS}\"}" \
        2>&1 | tee -a "$LOG_FILE" || warn "Dashboard API registration check may need manual setup."

    log "Wazuh Dashboard installed."
}

# ==============================================================================
# POST-INSTALL HARDENING
# ==============================================================================
post_install_hardening() {
    step "Post-Install Hardening"

    # Change default Indexer admin password
    curl -sk -X PUT "https://${WAZUH_MANAGER_IP}:9200/_plugins/_security/api/internalusers/admin" \
        -H 'Content-Type: application/json' \
        -u "admin:admin" \
        -d "{\"password\":\"${INDEXER_ADMIN_PASS}\",\"opendistro_security_roles\":[\"all_access\"]}" \
        2>&1 | tee -a "$LOG_FILE" || warn "Could not change admin password - do this manually."

    # Lock down permissions on sensitive files
    chmod 600 /var/ossec/etc/authd.pass
    chmod 600 /var/ossec/api/configuration/api.yaml

    # Re-enable SELinux after initial setup
    # NOTE: Uncomment after verifying full functionality
    # setenforce 1
    # sed -i 's/^SELINUX=permissive/SELINUX=enforcing/' /etc/selinux/config

    log "Post-install hardening applied."
}

# ==============================================================================
# SETUP AGENT DOWNLOAD PORTAL
# ==============================================================================
setup_agent_portal() {
    step "Setting Up Agent Download Web Portal"

    dnf install -y --disablerepo='*' --enablerepo='deps-local' \
        nginx 2>&1 | tee -a "$LOG_FILE" || \
        warn "nginx not available in local repo. Portal setup skipped. Install manually."

    command -v nginx &>/dev/null || {
        warn "nginx not installed. Copying portal files only."
        cp -r "${OFFLINE_DIR}/web-portal" /opt/wazuh-portal
        return
    }

    # Copy pre-built portal HTML (generated separately)
    mkdir -p /var/www/wazuh-portal
    cp -r "${OFFLINE_DIR}/web-portal/." /var/www/wazuh-portal/

    # Copy agents for download
    cp -r "${OFFLINE_DIR}/agents/" /var/www/wazuh-portal/downloads/

    cat > /etc/nginx/conf.d/wazuh-portal.conf <<EOF
server {
    listen 8080;
    server_name ${WAZUH_MANAGER_IP};
    root /var/www/wazuh-portal;
    index index.html;
    autoindex off;

    location /downloads/ {
        autoindex on;
        autoindex_exact_size off;
        autoindex_localtime on;
    }

    location / {
        try_files \$uri \$uri/ /index.html;
    }
}
EOF

    systemctl enable --now nginx
    firewall-cmd --permanent --add-port=8080/tcp && firewall-cmd --reload || true

    log "Agent download portal running on http://${WAZUH_MANAGER_IP}:8080"
}

# ==============================================================================
# PRINT INSTALLATION SUMMARY
# ==============================================================================
print_summary() {
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Wazuh Community Edition - Installation Complete!"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "  Dashboard URL  : https://${WAZUH_MANAGER_IP}"
    echo "  Default Login  : admin / ${INDEXER_ADMIN_PASS}"
    echo ""
    echo "  Agent Registration Port : 1515/tcp"
    echo "  Agent Registration Pass : ${AGENT_REG_PASS}"
    echo "  Agent Download Portal   : http://${WAZUH_MANAGER_IP}:8080"
    echo "  Manager API             : https://${WAZUH_MANAGER_IP}:55000"
    echo ""
    echo "  Install Log    : ${LOG_FILE}"
    echo ""
    echo "  Service Status:"
    for svc in wazuh-indexer wazuh-manager wazuh-dashboard nginx; do
        STATUS=$(systemctl is-active "$svc" 2>/dev/null || echo "not installed")
        printf "    %-22s : %s\n" "$svc" "$STATUS"
    done
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

# ==============================================================================
# MAIN
# ==============================================================================
main() {
    echo ""
    echo "  ╔══════════════════════════════════════════════════════╗"
    echo "  ║   Wazuh ${WAZUH_VERSION} - Air-Gapped Installer              ║"
    echo "  ║   Anderson Computer Consulting                       ║"
    echo "  ╚══════════════════════════════════════════════════════╝"
    echo ""

    preflight
    prepare_system
    generate_certificates
    install_indexer
    install_manager
    install_dashboard
    post_install_hardening
    setup_agent_portal
    print_summary
}

main "$@"
