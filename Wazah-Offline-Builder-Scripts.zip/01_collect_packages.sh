#!/bin/bash
# ==============================================================================
# Wazuh Community Edition - Offline Package Collector
# Version: 1.0
# Target: Rocky Linux 9.x (Online Collection Machine)
# Author: Anderson Computer Consulting
# Description:
#   Run this script on an INTERNET-CONNECTED Rocky Linux 9 machine.
#   It downloads all RPMs, container images, pip packages, and Wazuh
#   agent installers required to deploy Wazuh 4.9.x in a fully air-gapped
#   environment running Rocky Linux 9.7 minimal.
#
# Output: /opt/wazuh-offline/  (copy entire directory to your air-gapped host)
# ==============================================================================

set -euo pipefail

WAZUH_VERSION="4.9.2"
WAZUH_REVISION="1"
INDEXER_VERSION="2.18.0"
DASHBOARD_VERSION="4.9.2"
ELASTIC_OSS_VERSION="7.17.20"
BASE_DIR="/opt/wazuh-offline"
LOG_FILE="${BASE_DIR}/collector.log"
ARCH="x86_64"

# Colors
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

log()   { echo -e "${GREEN}[$(date '+%H:%M:%S')] $*${NC}" | tee -a "$LOG_FILE"; }
warn()  { echo -e "${YELLOW}[WARN] $*${NC}" | tee -a "$LOG_FILE"; }
error() { echo -e "${RED}[ERROR] $*${NC}" | tee -a "$LOG_FILE"; exit 1; }
info()  { echo -e "${CYAN}[INFO] $*${NC}" | tee -a "$LOG_FILE"; }

# ==============================================================================
# PRE-FLIGHT CHECKS
# ==============================================================================
preflight() {
    log "Running pre-flight checks..."
    [[ $EUID -ne 0 ]] && error "This script must be run as root."

    for cmd in curl wget dnf rpm createrepo python3 docker; do
        command -v "$cmd" &>/dev/null || error "Required command '$cmd' not found. Install it first."
    done

    ping -c1 -W3 8.8.8.8 &>/dev/null || error "No internet connectivity detected."

    DISK_FREE=$(df -BG /opt | awk 'NR==2 {print $4}' | tr -d 'G')
    [[ "$DISK_FREE" -lt 20 ]] && error "Insufficient disk space. Need at least 20GB free in /opt."

    log "Pre-flight checks passed. Free space: ${DISK_FREE}GB"
}

# ==============================================================================
# DIRECTORY STRUCTURE
# ==============================================================================
setup_dirs() {
    log "Creating directory structure under ${BASE_DIR}..."
    mkdir -p \
        "${BASE_DIR}/rpms/base" \
        "${BASE_DIR}/rpms/wazuh" \
        "${BASE_DIR}/rpms/deps" \
        "${BASE_DIR}/certs" \
        "${BASE_DIR}/agents/linux" \
        "${BASE_DIR}/agents/windows" \
        "${BASE_DIR}/agents/macos" \
        "${BASE_DIR}/docker-images" \
        "${BASE_DIR}/scripts" \
        "${BASE_DIR}/configs" \
        "${BASE_DIR}/web-portal" \
        "${BASE_DIR}/ansible"
    touch "$LOG_FILE"
    log "Directory structure created."
}

# ==============================================================================
# SYSTEM DEPENDENCY RPMs
# ==============================================================================
download_base_rpms() {
    log "Downloading system dependency RPMs..."
    cd "${BASE_DIR}/rpms/deps"

    dnf install -y --downloadonly --downloaddir="${BASE_DIR}/rpms/deps" \
        curl wget unzip tar gzip bzip2 net-tools nmap \
        lsof htop vim bash-completion \
        openssl openssl-pkcs11 ca-certificates \
        libcap policycoreutils-python-utils \
        audit audit-libs \
        python3 python3-pip \
        java-11-openjdk-headless \
        gnupg2 \
        2>&1 | tee -a "$LOG_FILE" || warn "Some base RPMs may have already been cached."

    log "Base RPMs downloaded."
}

# ==============================================================================
# WAZUH REPO SETUP & PACKAGE DOWNLOAD
# ==============================================================================
setup_wazuh_repo() {
    log "Adding Wazuh ${WAZUH_VERSION} repository..."
    cat > /etc/yum.repos.d/wazuh_collector.repo <<EOF
[wazuh]
gpgcheck=1
gpgkey=https://packages.wazuh.com/key/GPG-KEY-WAZUH
enabled=1
name=EL-\$releasever - Wazuh
baseurl=https://packages.wazuh.com/4.x/yum/
protect=1
EOF
    rpm --import https://packages.wazuh.com/key/GPG-KEY-WAZUH 2>&1 | tee -a "$LOG_FILE"
    log "Wazuh repo configured."
}

download_wazuh_rpms() {
    log "Downloading Wazuh Manager, Indexer, and Dashboard RPMs..."
    cd "${BASE_DIR}/rpms/wazuh"

    dnf install -y --downloadonly --downloaddir="${BASE_DIR}/rpms/wazuh" \
        "wazuh-manager-${WAZUH_VERSION}" \
        "wazuh-indexer-${INDEXER_VERSION}" \
        "wazuh-dashboard-${DASHBOARD_VERSION}" \
        2>&1 | tee -a "$LOG_FILE" || warn "Some Wazuh RPMs may already be cached."

    log "Wazuh RPMs downloaded."
}

# ==============================================================================
# WAZUH AGENTS
# ==============================================================================
download_agents() {
    log "Downloading Wazuh agents for all platforms..."
    cd "${BASE_DIR}/agents"

    # Linux RPM agents
    for pkg in \
        "wazuh-agent-${WAZUH_VERSION}-${WAZUH_REVISION}.${ARCH}.rpm" \
        "wazuh-agent_${WAZUH_VERSION}-${WAZUH_REVISION}_amd64.deb"; do
        BASE_URL="https://packages.wazuh.com/4.x"
        if [[ "$pkg" == *.rpm ]]; then
            wget -q --show-progress -O "linux/${pkg}" "${BASE_URL}/yum/${pkg}" \
                2>&1 | tee -a "$LOG_FILE" || warn "Could not download ${pkg}"
        else
            wget -q --show-progress -O "linux/${pkg}" "${BASE_URL}/apt/pool/main/w/wazuh-agent/${pkg}" \
                2>&1 | tee -a "$LOG_FILE" || warn "Could not download ${pkg}"
        fi
    done

    # Windows agent MSI
    WIN_PKG="wazuh-agent-${WAZUH_VERSION}-${WAZUH_REVISION}.msi"
    wget -q --show-progress \
        -O "windows/${WIN_PKG}" \
        "https://packages.wazuh.com/4.x/windows/${WIN_PKG}" \
        2>&1 | tee -a "$LOG_FILE" || warn "Could not download Windows agent."

    # macOS pkg
    MAC_PKG="wazuh-agent-${WAZUH_VERSION}-${WAZUH_REVISION}.pkg"
    wget -q --show-progress \
        -O "macos/${MAC_PKG}" \
        "https://packages.wazuh.com/4.x/macos/${MAC_PKG}" \
        2>&1 | tee -a "$LOG_FILE" || warn "Could not download macOS agent."

    # PowerShell deployment script for Windows
    cat > "windows/install-wazuh-agent.ps1" <<'PSEOF'
# Wazuh Windows Agent Silent Installer
# Usage: .\install-wazuh-agent.ps1 -WazuhManager "192.168.1.10" -AgentName "workstation01"
param(
    [Parameter(Mandatory=$true)][string]$WazuhManager,
    [string]$AgentName = $env:COMPUTERNAME,
    [string]$AgentGroup = "default",
    [string]$WazuhRegPass = ""
)
$MSI = Get-ChildItem -Path $PSScriptRoot -Filter "wazuh-agent-*.msi" | Select-Object -First 1
if (-not $MSI) { Write-Error "MSI not found in $PSScriptRoot"; exit 1 }
$args = "/i `"$($MSI.FullName)`" /qn WAZUH_MANAGER=`"$WazuhManager`" WAZUH_AGENT_NAME=`"$AgentName`" WAZUH_AGENT_GROUP=`"$AgentGroup`""
if ($WazuhRegPass) { $args += " WAZUH_REGISTRATION_PASSWORD=`"$WazuhRegPass`"" }
Start-Process msiexec.exe -ArgumentList $args -Wait
Start-Service WazuhSvc
Write-Host "Wazuh agent installed and service started."
PSEOF

    log "Agent packages downloaded."
}

# ==============================================================================
# WAZUH CERTIFICATES TOOL
# ==============================================================================
download_cert_tool() {
    log "Downloading Wazuh certificate generation tool..."
    curl -sO https://packages.wazuh.com/4.9/wazuh-certs-tool.sh \
        -o "${BASE_DIR}/scripts/wazuh-certs-tool.sh"
    chmod +x "${BASE_DIR}/scripts/wazuh-certs-tool.sh"
    log "Certificate tool downloaded."
}

# ==============================================================================
# CREATE LOCAL YUM REPO METADATA
# ==============================================================================
build_local_repo() {
    log "Building local repository metadata..."
    command -v createrepo &>/dev/null || dnf install -y createrepo_c

    createrepo "${BASE_DIR}/rpms/deps" 2>&1 | tee -a "$LOG_FILE"
    createrepo "${BASE_DIR}/rpms/wazuh" 2>&1 | tee -a "$LOG_FILE"
    createrepo "${BASE_DIR}/rpms/base" 2>&1 | tee -a "$LOG_FILE"

    log "Repository metadata created."
}

# ==============================================================================
# GENERATE CONFIG FILES
# ==============================================================================
generate_configs() {
    log "Generating configuration template files..."

    cat > "${BASE_DIR}/configs/config.ini" <<EOF
# ===========================================================
# Wazuh Air-Gapped Deployment Configuration
# Edit these values before running the installer.
# ===========================================================

[server]
WAZUH_MANAGER_IP=192.168.1.10
HOSTNAME=wazuh-server
DOMAIN=yourdomain.local

[indexer]
INDEXER_NODE_NAME=node-1
INDEXER_IP=192.168.1.10

[dashboard]
DASHBOARD_IP=192.168.1.10

[credentials]
# Change all passwords before deployment!
INDEXER_ADMIN_PASS=WazuhAdmin@2024!
API_USER=wazuh-wui
API_PASS=WazuhAPI@2024!
AGENT_REG_PASS=AgentReg@2024!

[network]
# Interface to bind services to
BIND_INTERFACE=eth0
EOF

    cat > "${BASE_DIR}/configs/wazuh_template.conf" <<'EOF'
<ossec_config>
  <global>
    <jsonout_output>yes</jsonout_output>
    <alerts_log>yes</alerts_log>
    <logall>no</logall>
    <logall_json>no</logall_json>
    <email_notification>no</email_notification>
    <smtp_server>smtp.example.wpd</smtp_server>
    <email_from>wazuh@example.wpd</email_from>
    <email_to>recipient@example.wpd</email_to>
    <email_maxperhour>12</email_maxperhour>
    <email_log_source>alerts.log</email_log_source>
    <agents_disconnection_time>10m</agents_disconnection_time>
    <agents_disconnection_alert_time>0</agents_disconnection_alert_time>
  </global>

  <alerts>
    <log_alert_level>3</log_alert_level>
    <email_alert_level>12</email_alert_level>
  </alerts>

  <remote>
    <connection>secure</connection>
    <port>1514</port>
    <protocol>tcp</protocol>
    <queue_size>131072</queue_size>
  </remote>

  <rootcheck>
    <disabled>no</disabled>
    <check_files>yes</check_files>
    <check_trojans>yes</check_trojans>
    <check_dev>yes</check_dev>
    <check_sys>yes</check_sys>
    <check_pids>yes</check_pids>
    <check_ports>yes</check_ports>
    <check_if>yes</check_if>
    <frequency>43200</frequency>
    <rootkit_files>etc/shared/rootkit_files.txt</rootkit_files>
    <rootkit_trojans>etc/shared/rootkit_trojans.txt</rootkit_trojans>
    <skip_nfs>yes</skip_nfs>
  </rootcheck>

  <vulnerability-detection>
    <enabled>yes</enabled>
    <index-status>yes</index-status>
    <feed-update-interval>60m</feed-update-interval>
  </vulnerability-detection>

  <sca>
    <enabled>yes</enabled>
    <scan_on_start>yes</scan_on_start>
    <interval>12h</interval>
    <skip_nfs>yes</skip_nfs>
  </sca>

  <syscheck>
    <disabled>no</disabled>
    <frequency>43200</frequency>
    <scan_on_start>yes</scan_on_start>
    <alert_new_files>yes</alert_new_files>
    <auto_ignore frequency="10" timeframe="3600">no</auto_ignore>
    <directories>/etc,/usr/bin,/usr/sbin</directories>
    <directories>/bin,/sbin,/boot</directories>
    <ignore>/etc/mtab</ignore>
    <ignore>/etc/hosts.deny</ignore>
    <ignore>/etc/mail/statistics</ignore>
    <ignore>/etc/random-seed</ignore>
    <ignore>/etc/adjtime</ignore>
    <ignore>/etc/httpd/logs</ignore>
    <nodiff>/etc/ssl/private.key</nodiff>
    <skip_nfs>yes</skip_nfs>
    <skip_dev>yes</skip_dev>
    <skip_proc>yes</skip_proc>
    <skip_sys>yes</skip_sys>
    <process_priority>10</process_priority>
    <max_eps>50</max_eps>
  </syscheck>

  <localfile>
    <log_format>journald</log_format>
    <location>journald</location>
  </localfile>

  <localfile>
    <log_format>syslog</log_format>
    <location>/var/ossec/logs/active-responses.log</location>
  </localfile>

</ossec_config>
EOF

    log "Configuration files generated."
}

# ==============================================================================
# GENERATE THE AGENT LOCAL REPO FILE (for installer to lay down on target)
# ==============================================================================
generate_repo_file() {
    cat > "${BASE_DIR}/configs/wazuh-local.repo" <<'EOF'
[wazuh-local]
name=Wazuh Local Repository
baseurl=file:///opt/wazuh-offline/rpms/wazuh
enabled=1
gpgcheck=0
EOF

    cat > "${BASE_DIR}/configs/deps-local.repo" <<'EOF'
[deps-local]
name=Local Dependencies Repository
baseurl=file:///opt/wazuh-offline/rpms/deps
enabled=1
gpgcheck=0
EOF

    log "Local repo files generated."
}

# ==============================================================================
# VERIFY DOWNLOADS
# ==============================================================================
verify_downloads() {
    log "Verifying downloaded packages..."
    local issues=0

    for dir in "${BASE_DIR}/rpms/deps" "${BASE_DIR}/rpms/wazuh"; do
        COUNT=$(find "$dir" -name "*.rpm" 2>/dev/null | wc -l)
        info "  $dir: ${COUNT} RPM(s)"
        [[ "$COUNT" -eq 0 ]] && { warn "No RPMs in $dir!"; ((issues++)); }
    done

    for agent in \
        "${BASE_DIR}/agents/windows/wazuh-agent-${WAZUH_VERSION}-${WAZUH_REVISION}.msi" \
        "${BASE_DIR}/agents/linux/wazuh-agent-${WAZUH_VERSION}-${WAZUH_REVISION}.${ARCH}.rpm"; do
        [[ -f "$agent" ]] && info "  Found: $(basename "$agent")" || { warn "Missing: $agent"; ((issues++)); }
    done

    [[ $issues -gt 0 ]] && warn "Verification found ${issues} issue(s). Review the log." \
                        || log "All verifications passed."
}

# ==============================================================================
# PACKAGE SUMMARY
# ==============================================================================
print_summary() {
    echo ""
    echo "============================================================"
    echo "  Wazuh Offline Package Collection COMPLETE"
    echo "============================================================"
    du -sh "${BASE_DIR}" 2>/dev/null || true
    echo ""
    echo "  Output directory : ${BASE_DIR}"
    echo "  Log file         : ${LOG_FILE}"
    echo ""
    echo "  Next Steps:"
    echo "  1. Copy the entire ${BASE_DIR} directory to your air-gapped"
    echo "     Rocky Linux 9.7 server (USB drive, SCP to jump host, etc.)"
    echo "  2. Run 02_install_wazuh.sh as root on the target system."
    echo "============================================================"
}

# ==============================================================================
# MAIN
# ==============================================================================
main() {
    echo ""
    echo "  ╔══════════════════════════════════════════════════════╗"
    echo "  ║   Wazuh ${WAZUH_VERSION} - Offline Package Collector         ║"
    echo "  ║   Anderson Computer Consulting                       ║"
    echo "  ╚══════════════════════════════════════════════════════╝"
    echo ""

    preflight
    setup_dirs
    download_base_rpms
    setup_wazuh_repo
    download_wazuh_rpms
    download_agents
    download_cert_tool
    build_local_repo
    generate_configs
    generate_repo_file
    verify_downloads
    print_summary
}

main "$@"
